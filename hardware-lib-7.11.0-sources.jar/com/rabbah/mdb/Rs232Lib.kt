package com.rabbah.mdb

import android.content.Context
import android.content.SharedPreferences
import android.hardware.rs232.RS232
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * RS232 support over the CM30's serial port (vendor class android.hardware.rs232.RS232) -
 * the third hardware pillar next to the MDB engine and PulseLib.
 *
 * THE MODEL - a configurable RX -> TX rule table (up to [MAX_RULES] entries): the machine
 * sends a hex frame, the library matches it against the rules IN ORDER and immediately writes
 * the matched rule's reply back on the wire. Rules are added at runtime (from code or from the
 * dashboard/backend as JSON), persisted across restarts, and hot-reloaded - "tx this when rx
 * this", and it starts working:
 *
 *   Rs232Lib.setRulesJson(""\"[
 *     {"name":"STATUS",       "rx":"FF FF FF FF FF",    "tx":"01 00"},
 *     {"name":"VEND_REQUEST", "rx":"F1 05 ?? ?? 0D",    "tx":"06",  "priceHi":2, "priceLo":3}
 *   ]""\")
 *   Rs232Lib.open(baud = 9600)
 *
 * MATCHING: a rule's rx is hex bytes where "??" matches ANY byte - that is how a VEND REQUEST
 * whose price changes per sale still matches one rule. Frame length must equal the pattern
 * length. First matching rule wins.
 *
 * VEND REQUEST rules: set [Rs232Rule.priceHiIndex]/[priceLoIndex] to the byte positions
 * (0-based) carrying the price high/low bytes. On match the price (hi*256 + lo) is extracted
 * and [vendRequestListener] fires with it - approve by sending your approval frame via
 * [sendHex] (or configure the rule's tx to auto-ack immediately; both work together).
 *
 * FRAMING: RS232 is a raw byte stream with no frame markers, so frames are cut by silence -
 * bytes that arrive within [frameGapMs] of each other belong to one frame; a gap ends it.
 *
 * Every exchange is reported as "[rs232] ..." lines through the normal HardwareLib log
 * pipeline (screen + dashboard), and [exchangeListener] delivers the structured version.
 * No CM30 runtime degrades to reported failures and false returns, never a crash.
 */
object Rs232Lib {

    const val MAX_RULES = 20

    /** One RX -> TX mapping. [rx] is space-separated hex, "??" = any byte; [tx] is the reply
     * hex ("" = match + report + listener, but send nothing). [priceHiIndex]/[priceLoIndex]
     * mark the frame bytes carrying a vend price (-1 = not a vend rule). */
    data class Rs232Rule(
        val name: String,
        val rx: String,
        val tx: String,
        val priceHiIndex: Int = -1,
        val priceLoIndex: Int = -1
    )

    /** One matched (or unmatched) frame: the raw rx hex, the matched rule name (null when no
     * rule matched), the reply hex actually written (null when nothing was sent), and the
     * extracted price (-1 unless the rule declares price byte positions). */
    data class Rs232Exchange(
        val rxHex: String,
        val ruleName: String?,
        val txHex: String?,
        val price: Int,
        val timestampMs: Long
    )

    /** Fires on every received frame (matched or not), on the reader thread - return fast. */
    @JvmStatic
    @Volatile
    var exchangeListener: ((Rs232Exchange) -> Unit)? = null

    /** Fires when a rule with price byte positions matches: the extracted price (hi*256+lo)
     * and the full frame. Runs on the reader thread - hop to your own thread for gateway work,
     * then answer the machine with [sendHex]. */
    @JvmStatic
    @Volatile
    var vendRequestListener: ((price: Int, frameHex: String) -> Unit)? = null

    /** Silence that ends a frame, in ms. Adjustable for slow machines. */
    @JvmStatic
    @Volatile
    var frameGapMs: Int = 20

    private const val PREFS_NAME = "rs232_rules"
    private const val KEY_RULES = "rulesJson"
    private const val READ_BUF = 256

    private var prefs: SharedPreferences? = null
    @Volatile private var rules: List<Rs232Rule> = emptyList()

    private val running = AtomicBoolean(false)
    private var serial: RS232? = null

    /** True while the port is open and the reader loop is running. */
    val isOpen: Boolean
        get() = running.get()

    /** Restores persisted rules. Called by [HardwareLib.init] automatically; safe to call
     * directly when using Rs232Lib standalone. */
    @JvmStatic
    fun init(context: Context): Boolean {
        if (prefs != null) return true
        prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs?.getString(KEY_RULES, null)?.let { saved ->
            val err = setRulesJson(saved, persist = false)
            if (err != null) HardwareLib.reportLine("[rs232] saved rules ignored: $err")
        }
        return true
    }

    // ------------------------------------ rules ------------------------------------

    /**
     * Replaces the whole rule table from JSON - the same payload the dashboard/backend sends:
     *
     *   [ {"name":"STATUS","rx":"FF FF FF FF FF","tx":"01 00"},
     *     {"name":"VEND","rx":"F1 05 ?? ?? 0D","tx":"06","priceHi":2,"priceLo":3} ]
     *
     * Up to [MAX_RULES] entries; each rx must be valid hex/?? tokens, price indexes (when
     * given) must point inside the rx pattern. Persisted and applied to the NEXT frame - no
     * reopen needed. Returns null on success, else a human-readable error (table unchanged).
     */
    @JvmStatic
    @JvmOverloads
    fun setRulesJson(json: String, persist: Boolean = true): String? {
        val arr = try {
            JSONArray(json)
        } catch (e: Exception) {
            return "invalid JSON array: ${e.message}"
        }
        if (arr.length() > MAX_RULES) return "too many rules: ${arr.length()}, maximum is $MAX_RULES"
        val parsed = ArrayList<Rs232Rule>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: return "rule $i is not an object"
            val name = o.optString("name").ifEmpty { "RULE_$i" }
            val rx = o.optString("rx")
            val tx = o.optString("tx")
            val hi = o.optInt("priceHi", -1)
            val lo = o.optInt("priceLo", -1)
            val rxTokens = parsePattern(rx) ?: return "rule $name: rx is not valid hex/?? tokens: $rx"
            if (tx.isNotBlank() && parseHex(tx) == null) return "rule $name: tx is not valid hex: $tx"
            if ((hi >= 0) != (lo >= 0)) return "rule $name: priceHi and priceLo must be set together"
            if (hi >= rxTokens.size || lo >= rxTokens.size) {
                return "rule $name: price index outside the ${rxTokens.size}-byte rx pattern"
            }
            parsed.add(Rs232Rule(name, normalizePattern(rx), tx.trim().uppercase(), hi, lo))
        }
        rules = parsed
        if (persist) prefs?.edit()?.putString(KEY_RULES, rulesJson())?.apply()
        HardwareLib.reportLine("[rs232] ${parsed.size} rule(s) loaded")
        return null
    }

    /** The current rule table as JSON (the same shape [setRulesJson] accepts). */
    @JvmStatic
    fun rulesJson(): String {
        val arr = JSONArray()
        for (r in rules) {
            arr.put(JSONObject().apply {
                put("name", r.name)
                put("rx", r.rx)
                put("tx", r.tx)
                if (r.priceHiIndex >= 0) {
                    put("priceHi", r.priceHiIndex)
                    put("priceLo", r.priceLoIndex)
                }
            })
        }
        return arr.toString()
    }

    /** Removes every rule (persisted). Frames then only report as UNMATCHED. */
    @JvmStatic
    fun clearRules(): Boolean {
        rules = emptyList()
        prefs?.edit()?.remove(KEY_RULES)?.apply()
        HardwareLib.reportLine("[rs232] rules cleared")
        return true
    }

    // ------------------------------------ port ------------------------------------

    /**
     * Opens the serial port and starts the reader loop. Defaults: 9600 baud, 8 data bits,
     * 1 stop bit, no parity ('N'), no flow control ('N') - override any of them. Returns true
     * when the port opened; false (with a reported line) otherwise. Idempotent while open.
     */
    @JvmStatic
    @JvmOverloads
    fun open(
        baud: Int = 9600,
        dataBits: Int = 8,
        stopBits: Int = 1,
        parity: Char = 'N',
        flowControl: Char = 'N',
        port: Int = 0
    ): Boolean {
        if (running.getAndSet(true)) return true
        val s = try {
            RS232()
        } catch (t: Throwable) {
            running.set(false)
            HardwareLib.reportLine("[rs232] open failed - CM30 RS232 runtime unavailable (${t.javaClass.simpleName})")
            return false
        }
        val ret = try {
            s.RS232Open(port, baud, dataBits, stopBits, parity, flowControl)
        } catch (t: Throwable) {
            running.set(false)
            HardwareLib.reportLine("[rs232] open failed: ${t.javaClass.simpleName} ${t.message}")
            return false
        }
        if (ret < 0) {
            running.set(false)
            HardwareLib.reportLine("[rs232] open failed - RS232Open returned $ret")
            return false
        }
        serial = s
        HardwareLib.reportLine("[rs232] port open - baud=$baud ${dataBits}${parity}${stopBits}, ${rules.size} rule(s) active")
        thread(name = "Rs232Reader", isDaemon = true) {
            try {
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO)
            } catch (_: Throwable) {
            }
            readerLoop(s)
        }
        return true
    }

    /** Closes the port and stops the reader. True when it was open. */
    @JvmStatic
    fun close(): Boolean {
        val wasOpen = running.getAndSet(false)
        try { serial?.RS232Close() } catch (_: Throwable) {}
        serial = null
        if (wasOpen) HardwareLib.reportLine("[rs232] port closed")
        return wasOpen
    }

    /**
     * Writes raw hex to the machine RIGHT NOW - the manual TX for approvals and anything not
     * covered by an auto-reply rule. True when every byte was written.
     */
    @JvmStatic
    fun sendHex(hex: String): Boolean {
        val bytes = parseHex(hex)
        if (bytes == null || bytes.isEmpty()) {
            HardwareLib.reportLine("[rs232] sendHex rejected - invalid hex: $hex")
            return false
        }
        val s = serial
        if (s == null || !running.get()) {
            HardwareLib.reportLine("[rs232] sendHex rejected - port not open")
            return false
        }
        val ret = try {
            s.RS232Write(bytes)
        } catch (t: Throwable) {
            HardwareLib.reportLine("[rs232] sendHex failed: ${t.javaClass.simpleName}")
            return false
        }
        val ok = ret >= 0
        HardwareLib.reportLine(
            if (ok) "[rs232] tx ${toHex(bytes)}" else "[rs232] sendHex FAILED - RS232Write returned $ret"
        )
        return ok
    }

    /**
     * Test hook: feeds a fake received frame through the rule matcher exactly as if the machine
     * sent it - the reply is really written when the port is open, otherwise only logged. Lets
     * you verify a rule table (matching, price extraction, listeners) without hardware.
     */
    @JvmStatic
    fun simulateFrame(hex: String): Boolean {
        val bytes = parseHex(hex)
        if (bytes == null || bytes.isEmpty()) {
            HardwareLib.reportLine("[rs232] simulateFrame rejected - invalid hex: $hex")
            return false
        }
        processFrame(serial, bytes)
        return true
    }

    // ------------------------------------ reader ------------------------------------

    /** Reads the byte stream, cuts frames on [frameGapMs] of silence, and processes each one.
     * The reply (when a rule matches) is written BEFORE any logging - same send-first
     * discipline as the MDB engine. */
    private fun readerLoop(s: RS232) {
        val buf = ByteArray(READ_BUF)
        val frame = ArrayList<Byte>(READ_BUF)
        while (running.get()) {
            val n = try {
                s.RS232Read(buf, buf.size, if (frame.isEmpty()) 200 else frameGapMs)
            } catch (t: Throwable) {
                HardwareLib.reportLine("[rs232] read failed: ${t.javaClass.simpleName} - reader stopped")
                running.set(false)
                return
            }
            if (n > 0) {
                for (i in 0 until n) frame.add(buf[i])
                if (frame.size > 4096) { // runaway stream guard
                    processFrame(s, frame.toByteArray()); frame.clear()
                }
            } else if (frame.isNotEmpty()) {
                // Silence after data: the frame is complete.
                processFrame(s, frame.toByteArray())
                frame.clear()
            }
        }
    }

    private fun processFrame(s: RS232?, bytes: ByteArray) {
        val rule = rules.firstOrNull { matches(it, bytes) }
        var txHex: String? = null
        // 1. Reply first - the machine's reply window does not wait for our bookkeeping.
        if (rule != null && rule.tx.isNotBlank()) {
            val txBytes = parseHex(rule.tx)
            if (txBytes != null) {
                if (s != null) {
                    try {
                        s.RS232Write(txBytes)
                        txHex = rule.tx
                    } catch (t: Throwable) {
                        HardwareLib.reportLine("[rs232] reply write failed for ${rule.name}: ${t.javaClass.simpleName}")
                    }
                } else {
                    txHex = rule.tx // simulated frame, port closed: reply is logged, not written
                }
            }
        }
        // 2. Price extraction + vend hook.
        val rxHex = toHex(bytes)
        var price = -1
        if (rule != null && rule.priceHiIndex >= 0 && rule.priceLoIndex < bytes.size && rule.priceHiIndex < bytes.size) {
            price = (bytes[rule.priceHiIndex].toInt() and 0xFF) * 256 + (bytes[rule.priceLoIndex].toInt() and 0xFF)
            val p = price
            try { vendRequestListener?.invoke(p, rxHex) } catch (_: Throwable) {}
        }
        // 3. Report + structured event.
        HardwareLib.reportLine(
            when {
                rule == null -> "[rs232] rx=$rxHex UNMATCHED (no rule)"
                price >= 0 -> "[rs232] rx=$rxHex matched=${rule.name} price=$price tx=${txHex ?: "(none)"}"
                else -> "[rs232] rx=$rxHex matched=${rule.name} tx=${txHex ?: "(none)"}"
            }
        )
        try {
            exchangeListener?.invoke(Rs232Exchange(rxHex, rule?.name, txHex, price, System.currentTimeMillis()))
        } catch (_: Throwable) {
        }
    }

    // ------------------------------------ hex helpers ------------------------------------

    private fun matches(rule: Rs232Rule, bytes: ByteArray): Boolean {
        val tokens = parsePattern(rule.rx) ?: return false
        if (tokens.size != bytes.size) return false
        for (i in tokens.indices) {
            val t = tokens[i]
            if (t != -1 && t != (bytes[i].toInt() and 0xFF)) return false
        }
        return true
    }

    /** "FF ?? 0A" -> [0xFF, -1, 0x0A]; null when any token is invalid. */
    private fun parsePattern(pattern: String): IntArray? {
        val parts = pattern.trim().split(Regex("[\\s,]+")).filter { it.isNotEmpty() }
        if (parts.isEmpty()) return null
        val out = IntArray(parts.size)
        for (i in parts.indices) {
            val p = parts[i]
            out[i] = if (p == "??") -1
            else p.removePrefix("0x").removePrefix("0X").toIntOrNull(16)?.takeIf { it in 0..0xFF } ?: return null
        }
        return out
    }

    private fun normalizePattern(pattern: String): String =
        pattern.trim().split(Regex("[\\s,]+")).filter { it.isNotEmpty() }
            .joinToString(" ") { if (it == "??") "??" else String.format("%02X", it.removePrefix("0x").removePrefix("0X").toInt(16)) }

    private fun parseHex(hex: String): ByteArray? {
        val parts = hex.trim().split(Regex("[\\s,]+")).filter { it.isNotEmpty() }
        if (parts.isEmpty()) return null
        val out = ByteArray(parts.size)
        for (i in parts.indices) {
            val v = parts[i].removePrefix("0x").removePrefix("0X").toIntOrNull(16) ?: return null
            if (v !in 0..0xFF) return null
            out[i] = v.toByte()
        }
        return out
    }

    private fun toHex(bytes: ByteArray): String = bytes.joinToString(" ") { String.format("%02X", it) }
}
